#!bin/bash
ceph tell osd.0 bench 1000 1 --cluster PrivateCluster 2> /home/ubuntu/osd-tell_8threads.txt


